# turdbot
An all purpose discord bot written in discord.py
